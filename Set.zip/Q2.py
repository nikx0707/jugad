"""
Write a program to accept a binary number and convert it into decimal number.
"""

binary_string = input("Enter a binary number :")

decimal = int(binary_string, 2)

print(f"The decimal value is {decimal}")